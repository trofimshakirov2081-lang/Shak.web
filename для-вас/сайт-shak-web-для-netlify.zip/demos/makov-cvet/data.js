// Собрано генератором shak.web из demos/_configs/makov-cvet.json. Правьте настройки и пересобирайте.
window.SITE = {
  "id": "demo-makov-cvet",
  "rev": "2026-10-24T07:45:26.707Z",
  "brand": {
    "name": "Маков Цвет",
    "tagline": "Авторские букеты с бесплатной доставкой",
    "logo": "",
    "city": "Челябинск"
  },
  "hero": {
    "title": "Букеты, которые собирают руками, а не по шаблону",
    "text": "Авторские букеты и композиции в Челябинске. Доставим бесплатно, а перед отправкой пришлём фото.",
    "cta": "Выбрать букет",
    "photo": "img/hero.jpg"
  },
  "sections": {
    "catalogTitle": "Букеты и композиции",
    "catalogText": "Листайте и добавляйте в корзину, заказ уйдёт нам в WhatsApp.",
    "aboutTitle": "О мастерской",
    "aboutText": "Маков Цвет: цветочная мастерская на Мамина, 19/3. Каждый букет собираем под повод и под человека: спросим, кому он, и подберём цвета. Если не знаете, что выбрать, просто напишите, поможем.",
    "orderTitle": "Ваш букет",
    "addLabel": "В корзину"
  },
  "features": [
    {
      "icon": "🚚",
      "title": "Бесплатная доставка",
      "text": "Привезём по Челябинску к нужному времени."
    },
    {
      "icon": "🌺",
      "title": "Авторские букеты",
      "text": "Собираем под повод, а не из одной заготовки."
    },
    {
      "icon": "📸",
      "title": "Фото перед отправкой",
      "text": "Покажем букет до того, как он выедет."
    }
  ],
  "colors": {
    "main": "#C8241B",
    "accent": "#EF7A63",
    "bg": "#F9E6E1",
    "text": "#2B1513"
  },
  "fonts": {
    "head": "Geologica",
    "body": "Onest"
  },
  "currency": "₽",
  "items": [
    {
      "id": "i1",
      "name": "Одной единственной",
      "desc": "Большой букет красных роз",
      "price": 5100,
      "emoji": "🌹",
      "photo": "img/item-1.jpg",
      "tag": "Хит"
    },
    {
      "id": "i2",
      "name": "Ласковый август",
      "desc": "Подсолнухи с зеленью",
      "price": 1940,
      "emoji": "🌻",
      "photo": "img/item-2.jpg",
      "tag": ""
    },
    {
      "id": "i3",
      "name": "Грация",
      "desc": "Розовые хризантемы",
      "price": 1460,
      "emoji": "🌸",
      "photo": "img/item-3.jpg",
      "tag": ""
    },
    {
      "id": "i4",
      "name": "Витаминка",
      "desc": "Композиция с оранжевыми розами",
      "price": 1280,
      "emoji": "🧡",
      "photo": "img/item-4.jpg",
      "tag": "Композиция"
    },
    {
      "id": "i5",
      "name": "Самой красивой",
      "desc": "Яркая сборная композиция",
      "price": 990,
      "emoji": "💐",
      "photo": "img/item-5.jpg",
      "tag": "Композиция"
    },
    {
      "id": "i6",
      "name": "Матильда",
      "desc": "Розы с орхидеями",
      "price": 1850,
      "emoji": "🌷",
      "photo": "img/item-6.jpg",
      "tag": ""
    },
    {
      "id": "i7",
      "name": "Аромат хризантем",
      "desc": "Пышные кустовые хризантемы",
      "price": 1320,
      "emoji": "🌼",
      "photo": "img/item-7.jpg",
      "tag": ""
    }
  ],
  "contacts": {
    "phone": "",
    "whatsapp": "79000720616",
    "telegram": "",
    "instagram": "",
    "address": "ул. Мамина, 19/3",
    "hours": ""
  },
  "demo": {
    "banner": true,
    "pin": "1234"
  },
  "designs": [
    {
      "name": "Тёмный",
      "layout": "bold",
      "colors": {
        "main": "#EF7A63",
        "accent": "#C8241B",
        "bg": "#121212",
        "text": "#F4EFEA"
      },
      "fonts": {
        "head": "Unbounded",
        "body": "Manrope"
      }
    },
    {
      "name": "Классика",
      "layout": "classic"
    },
    {
      "name": "Минимализм",
      "layout": "minimal",
      "colors": {
        "main": "#961B14",
        "accent": "#EF7A63",
        "bg": "#FFFFFF",
        "text": "#161616"
      },
      "fonts": {
        "head": "Playfair Display",
        "body": "Inter"
      }
    }
  ],
  "design": 0,
  "credits": "Фото: Pexels",
  "extra": {
    "vk": "vk.com/idkarkusha",
    "commentHint": "Кому букет, адрес, дата и время доставки",
    "orderIntro": "Здравствуйте! Хочу заказать букет с сайта:",
    "emptyText": "Пока пусто. Выберите букет на витрине."
  }
};
